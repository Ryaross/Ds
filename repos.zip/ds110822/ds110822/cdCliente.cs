﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ds110822
{
    public partial class cdCliente : Form
    {
        public cdCliente()
        {
            InitializeComponent();
        }

        private void cdCliente_Load(object sender, EventArgs e)
        {

        }
    }
}
